Filter plugins (*.vdf) placed here are automatically loaded
by the 32-bit version of VirtualDub on startup.
